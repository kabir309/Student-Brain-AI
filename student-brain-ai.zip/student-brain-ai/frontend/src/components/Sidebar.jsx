import { useState } from "react";
import { deleteDocument } from "../utils/api";

export default function Sidebar({ open, documents, onUpload, onDeleteDoc, onToggle }) {
  const [deletingId, setDeletingId] = useState(null);

  const handleDelete = async (docId, filename) => {
    if (!confirm(`Remove "${filename}" from your knowledge base?`)) return;
    setDeletingId(docId);
    try {
      await deleteDocument(docId);
      onDeleteDoc(docId);
    } catch (e) {
      alert("Failed to delete document");
    } finally {
      setDeletingId(null);
    }
  };

  return (
    <>
      {/* Mobile overlay */}
      {open && (
        <div
          className="fixed inset-0 bg-black/60 z-20 lg:hidden"
          onClick={onToggle}
        />
      )}

      <aside
        className={`
          fixed lg:relative z-30 lg:z-auto
          flex flex-col h-full bg-gray-900 border-r border-gray-800
          transition-all duration-300 ease-in-out
          ${open ? "w-72 translate-x-0" : "w-0 -translate-x-full lg:translate-x-0 lg:w-0"}
          overflow-hidden
        `}
      >
        <div className="flex flex-col h-full w-72">
          {/* Header */}
          <div className="flex items-center gap-3 px-5 py-4 border-b border-gray-800">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-violet-500 to-indigo-600 flex items-center justify-center flex-shrink-0">
              <span className="text-white text-sm font-bold">🧠</span>
            </div>
            <div className="flex-1 min-w-0">
              <h1 className="text-sm font-semibold text-white truncate">Student Brain AI</h1>
              <p className="text-xs text-gray-500">Your study assistant</p>
            </div>
          </div>

          {/* Upload Button */}
          <div className="px-4 pt-4">
            <button
              onClick={onUpload}
              className="w-full flex items-center gap-2 px-4 py-2.5 rounded-xl bg-violet-600 hover:bg-violet-500 text-white text-sm font-medium transition-colors"
            >
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
              </svg>
              Upload Document
            </button>
          </div>

          {/* Documents List */}
          <div className="flex-1 overflow-y-auto px-4 py-3">
            <p className="text-xs font-medium text-gray-500 uppercase tracking-wider mb-2 px-1">
              Knowledge Base ({documents.length})
            </p>

            {documents.length === 0 ? (
              <div className="text-center py-8 px-4">
                <div className="w-12 h-12 rounded-full bg-gray-800 flex items-center justify-center mx-auto mb-3">
                  <svg className="w-6 h-6 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                  </svg>
                </div>
                <p className="text-xs text-gray-600">No documents yet.</p>
                <p className="text-xs text-gray-700 mt-1">Upload a PDF or text file to start.</p>
              </div>
            ) : (
              <div className="space-y-1">
                {documents.map((doc) => (
                  <div
                    key={doc.doc_id}
                    className="group flex items-start gap-2.5 px-3 py-2.5 rounded-lg hover:bg-gray-800 transition-colors"
                  >
                    {/* File icon */}
                    <div className="mt-0.5 flex-shrink-0">
                      <svg className="w-4 h-4 text-violet-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                      </svg>
                    </div>

                    {/* Doc info */}
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-medium text-gray-300 truncate leading-snug">
                        {doc.filename}
                      </p>
                      <p className="text-xs text-gray-600 mt-0.5">
                        {doc.chunk_count} sections indexed
                      </p>
                    </div>

                    {/* Delete button */}
                    <button
                      onClick={() => handleDelete(doc.doc_id, doc.filename)}
                      disabled={deletingId === doc.doc_id}
                      className="opacity-0 group-hover:opacity-100 flex-shrink-0 p-1 rounded hover:bg-red-900/50 text-gray-600 hover:text-red-400 transition-all"
                      title="Remove document"
                    >
                      {deletingId === doc.doc_id ? (
                        <svg className="w-3.5 h-3.5 animate-spin" fill="none" viewBox="0 0 24 24">
                          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                        </svg>
                      ) : (
                        <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                        </svg>
                      )}
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Footer */}
          <div className="px-5 py-3 border-t border-gray-800">
            <p className="text-xs text-gray-600 text-center">
              Powered by Claude AI + FAISS RAG
            </p>
          </div>
        </div>
      </aside>
    </>
  );
}
