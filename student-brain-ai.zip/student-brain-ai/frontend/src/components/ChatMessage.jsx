import { useEffect, useRef } from "react";

function parseMarkdown(text) {
  if (!text) return "";

  return text
    // Bold
    .replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>")
    // Italic
    .replace(/\*(.*?)\*/g, "<em>$1</em>")
    // Inline code
    .replace(/`([^`]+)`/g, '<code class="bg-gray-800 text-violet-300 px-1.5 py-0.5 rounded text-xs font-mono">$1</code>')
    // Headers
    .replace(/^### (.*$)/gm, '<h3 class="text-base font-semibold text-white mt-4 mb-2">$1</h3>')
    .replace(/^## (.*$)/gm, '<h2 class="text-lg font-semibold text-white mt-4 mb-2">$1</h2>')
    .replace(/^# (.*$)/gm, '<h1 class="text-xl font-bold text-white mt-4 mb-2">$1</h1>')
    // Numbered lists
    .replace(/^\d+\. (.*)$/gm, '<li class="ml-4 list-decimal text-gray-300">$1</li>')
    // Bullet points
    .replace(/^[•\-\*] (.*)$/gm, '<li class="ml-4 list-disc text-gray-300">$1</li>')
    // Horizontal rule
    .replace(/^---$/gm, '<hr class="border-gray-700 my-4" />')
    // Newlines to breaks (but not inside block elements)
    .replace(/\n\n/g, '</p><p class="mb-3">')
    .replace(/\n/g, "<br />");
}

function CursorBlink() {
  return (
    <span className="inline-block w-0.5 h-4 bg-violet-400 ml-0.5 animate-pulse align-middle" />
  );
}

export default function ChatMessage({ message }) {
  const isUser = message.role === "user";
  const contentRef = useRef(null);

  useEffect(() => {
    if (contentRef.current) {
      contentRef.current.scrollIntoView({ behavior: "smooth", block: "nearest" });
    }
  }, [message.content]);

  if (isUser) {
    return (
      <div className="flex justify-end">
        <div className="max-w-[75%] lg:max-w-[60%]">
          <div className="bg-violet-600 text-white rounded-2xl rounded-tr-sm px-4 py-3 text-sm leading-relaxed">
            {message.content}
          </div>
        </div>
      </div>
    );
  }

  // Assistant message
  return (
    <div className="flex gap-3 max-w-3xl mx-auto" ref={contentRef}>
      {/* Avatar */}
      <div className="flex-shrink-0 w-8 h-8 rounded-full bg-gradient-to-br from-violet-500 to-indigo-600 flex items-center justify-center text-sm mt-1">
        🧠
      </div>

      {/* Content */}
      <div className="flex-1 min-w-0">
        {message.content ? (
          <div
            className={`text-sm text-gray-200 leading-relaxed prose-sm ${message.error ? "text-red-400" : ""}`}
          >
            <div
              dangerouslySetInnerHTML={{
                __html: `<p class="mb-3">${parseMarkdown(message.content)}</p>`,
              }}
            />
            {message.streaming && <CursorBlink />}
          </div>
        ) : (
          // Loading skeleton
          <div className="space-y-2 pt-1">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-violet-500 animate-bounce" style={{ animationDelay: "0ms" }} />
              <div className="w-2 h-2 rounded-full bg-violet-500 animate-bounce" style={{ animationDelay: "150ms" }} />
              <div className="w-2 h-2 rounded-full bg-violet-500 animate-bounce" style={{ animationDelay: "300ms" }} />
              <span className="text-xs text-gray-600 ml-1">Thinking...</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
