import { useState, useRef, useCallback } from "react";
import { uploadDocument } from "../utils/api";

const STAGES = {
  IDLE: "idle",
  UPLOADING: "uploading",
  SUCCESS: "success",
  ERROR: "error",
};

export default function UploadModal({ onClose, onSuccess }) {
  const [stage, setStage] = useState(STAGES.IDLE);
  const [dragOver, setDragOver] = useState(false);
  const [progress, setProgress] = useState(0);
  const [statusText, setStatusText] = useState("");
  const [error, setError] = useState("");
  const fileInputRef = useRef(null);

  const processFile = async (file) => {
    if (!file) return;

    const isValid = file.name.endsWith(".pdf") || file.name.endsWith(".txt");
    if (!isValid) {
      setError("Only PDF and TXT files are supported.");
      setStage(STAGES.ERROR);
      return;
    }

    setStage(STAGES.UPLOADING);
    setProgress(10);
    setStatusText("Reading file...");
    setError("");

    try {
      setProgress(30);
      setStatusText("Extracting text...");

      const result = await uploadDocument(file, (p) => {
        setProgress(30 + p * 0.6);
      });

      setProgress(95);
      setStatusText("Finalizing index...");

      await new Promise((r) => setTimeout(r, 400));
      setProgress(100);
      setStage(STAGES.SUCCESS);

      setTimeout(() => {
        onSuccess(result);
      }, 800);
    } catch (err) {
      setError(err.message || "Upload failed. Please try again.");
      setStage(STAGES.ERROR);
    }
  };

  const handleDrop = useCallback((e) => {
    e.preventDefault();
    setDragOver(false);
    const file = e.dataTransfer.files[0];
    processFile(file);
  }, []);

  const handleFileChange = (e) => {
    const file = e.target.files?.[0];
    processFile(file);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
      <div className="bg-gray-900 border border-gray-700 rounded-2xl w-full max-w-md shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-gray-800">
          <h2 className="text-base font-semibold text-white">Upload Document</h2>
          <button
            onClick={onClose}
            disabled={stage === STAGES.UPLOADING}
            className="p-1.5 rounded-lg hover:bg-gray-800 text-gray-500 hover:text-gray-300 transition-colors disabled:opacity-50"
          >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        <div className="p-6">
          {stage === STAGES.IDLE || stage === STAGES.ERROR ? (
            <>
              {/* Drop Zone */}
              <div
                onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
                onDragLeave={() => setDragOver(false)}
                onDrop={handleDrop}
                onClick={() => fileInputRef.current?.click()}
                className={`
                  relative border-2 border-dashed rounded-xl p-10 text-center cursor-pointer transition-all
                  ${dragOver
                    ? "border-violet-500 bg-violet-900/20"
                    : "border-gray-700 hover:border-violet-700 hover:bg-gray-800/50"
                  }
                `}
              >
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".pdf,.txt"
                  onChange={handleFileChange}
                  className="hidden"
                />

                <div className="w-14 h-14 rounded-full bg-gray-800 flex items-center justify-center mx-auto mb-4">
                  <svg className="w-7 h-7 text-violet-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
                  </svg>
                </div>

                <p className="text-sm font-medium text-gray-300 mb-1">
                  Drop your file here, or <span className="text-violet-400">browse</span>
                </p>
                <p className="text-xs text-gray-600">PDF or TXT · Max 20MB</p>
              </div>

              {stage === STAGES.ERROR && (
                <div className="mt-4 flex items-start gap-2 px-4 py-3 rounded-xl bg-red-900/30 border border-red-800">
                  <svg className="w-4 h-4 text-red-400 flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  <p className="text-xs text-red-300">{error}</p>
                </div>
              )}

              <div className="mt-4 grid grid-cols-3 gap-3">
                {[
                  { icon: "📚", label: "Textbooks" },
                  { icon: "📝", label: "Notes" },
                  { icon: "📄", label: "Articles" },
                ].map((item) => (
                  <div key={item.label} className="flex flex-col items-center gap-1 py-3 rounded-xl bg-gray-800/50 text-xs text-gray-500">
                    <span className="text-xl">{item.icon}</span>
                    {item.label}
                  </div>
                ))}
              </div>
            </>
          ) : stage === STAGES.UPLOADING ? (
            <div className="py-6 text-center">
              <div className="w-16 h-16 rounded-full bg-gray-800 flex items-center justify-center mx-auto mb-5 relative">
                <svg className="w-8 h-8 text-violet-400 animate-pulse" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
                </svg>
              </div>
              <p className="text-sm font-medium text-gray-200 mb-1">{statusText}</p>
              <p className="text-xs text-gray-600 mb-5">Building your knowledge base...</p>

              {/* Progress bar */}
              <div className="w-full bg-gray-800 rounded-full h-1.5 overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-violet-600 to-indigo-500 rounded-full transition-all duration-300"
                  style={{ width: `${progress}%` }}
                />
              </div>
              <p className="text-xs text-gray-700 mt-2">{Math.round(progress)}%</p>
            </div>
          ) : (
            <div className="py-8 text-center">
              <div className="w-16 h-16 rounded-full bg-emerald-900/40 flex items-center justify-center mx-auto mb-4">
                <svg className="w-8 h-8 text-emerald-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
              </div>
              <p className="text-sm font-semibold text-white mb-1">Document indexed!</p>
              <p className="text-xs text-gray-500">Redirecting to chat...</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
