import { useState, useEffect } from "react";
import Sidebar from "./components/Sidebar";
import ChatWindow from "./components/ChatWindow";
import UploadModal from "./components/UploadModal";
import { getDocuments } from "./utils/api";

export default function App() {
  const [documents, setDocuments] = useState([]);
  const [showUpload, setShowUpload] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [messages, setMessages] = useState([
    {
      role: "assistant",
      content: "👋 Hi! I'm **Student Brain AI** — your personal study assistant.\n\nUpload your notes, textbooks, or any PDF, and I'll help you understand anything in them. Ask me to explain concepts, summarize sections, or quiz you on the material.\n\n**Get started by uploading a document →**",
      id: "welcome",
    },
  ]);

  useEffect(() => {
    loadDocuments();
  }, []);

  const loadDocuments = async () => {
    try {
      const data = await getDocuments();
      setDocuments(data.documents || []);
    } catch (e) {
      console.error("Failed to load documents:", e);
    }
  };

  const handleUploadSuccess = (newDoc) => {
    setDocuments((prev) => [...prev, newDoc]);
    setShowUpload(false);
    setMessages((prev) => [
      ...prev,
      {
        role: "assistant",
        content: `✅ **"${newDoc.filename}"** has been uploaded and indexed into **${newDoc.chunk_count} sections**.\n\nI'm ready to answer questions about it! What would you like to know?`,
        id: Date.now().toString(),
      },
    ]);
  };

  const handleDeleteDoc = (docId) => {
    setDocuments((prev) => prev.filter((d) => d.doc_id !== docId));
  };

  return (
    <div className="flex h-screen bg-gray-950 text-gray-100 overflow-hidden">
      {/* Sidebar */}
      <Sidebar
        open={sidebarOpen}
        documents={documents}
        onUpload={() => setShowUpload(true)}
        onDeleteDoc={handleDeleteDoc}
        onToggle={() => setSidebarOpen((v) => !v)}
      />

      {/* Main Chat */}
      <ChatWindow
        messages={messages}
        setMessages={setMessages}
        hasDocuments={documents.length > 0}
        onUploadClick={() => setShowUpload(true)}
        sidebarOpen={sidebarOpen}
        onToggleSidebar={() => setSidebarOpen((v) => !v)}
      />

      {/* Upload Modal */}
      {showUpload && (
        <UploadModal
          onClose={() => setShowUpload(false)}
          onSuccess={handleUploadSuccess}
        />
      )}
    </div>
  );
}
