# 🧠 Student Brain AI

> An AI-powered study assistant that reads your documents and answers questions like a great teacher. Built with FastAPI, FAISS, React, and Claude AI.

---

## ✨ Features

- **PDF & TXT upload** — drag-and-drop or click to upload
- **Smart RAG pipeline** — FAISS vector search + semantic embeddings
- **Streaming AI responses** — token-by-token like ChatGPT
- **Teacher-mode AI** — explains with examples, never hallucinates
- **Multi-document knowledge base** — index many files, search them all
- **Delete documents** — manage your knowledge base
- **Responsive UI** — works on mobile and desktop

---

## 🗂 Project Structure

```
student-brain-ai/
├── backend/
│   ├── app/
│   │   ├── main.py              # FastAPI app entry
│   │   ├── api/
│   │   │   ├── upload.py        # PDF upload endpoint
│   │   │   ├── chat.py          # Chat + streaming endpoint
│   │   │   └── documents.py     # Document management
│   │   ├── core/
│   │   │   └── rag.py           # FAISS indexing + search
│   │   └── services/
│   │       ├── extractor.py     # PDF/TXT text extraction
│   │       └── ai.py            # Claude AI integration
│   ├── requirements.txt
│   ├── Dockerfile
│   └── .env.example
├── frontend/
│   ├── src/
│   │   ├── App.jsx              # Root component
│   │   ├── components/
│   │   │   ├── Sidebar.jsx      # Document list + upload
│   │   │   ├── ChatWindow.jsx   # Chat interface
│   │   │   ├── ChatMessage.jsx  # Message with markdown
│   │   │   └── UploadModal.jsx  # Upload with progress
│   │   └── utils/api.js         # API client (streaming)
│   ├── package.json
│   ├── vite.config.js
│   ├── tailwind.config.js
│   ├── Dockerfile
│   └── nginx.conf
└── cloudbuild.yaml              # Google Cloud deployment
```

---

## 🚀 Local Setup (5 Minutes)

### Prerequisites
- Python 3.10+
- Node.js 18+
- Anthropic API key → https://console.anthropic.com

### Step 1: Backend

```bash
cd backend

# Create virtual environment
python -m venv venv
source venv/bin/activate   # Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Configure environment
cp .env.example .env
# Edit .env and add: ANTHROPIC_API_KEY=sk-ant-...

# Run backend
uvicorn app.main:app --reload --port 8000
```

Backend runs at: http://localhost:8000
API docs at: http://localhost:8000/docs

### Step 2: Frontend

```bash
cd frontend

# Install dependencies
npm install

# Run frontend
npm run dev
```

Frontend runs at: http://localhost:3000

---

## 🌐 Deploy to Google Cloud (Free Tier Eligible)

### Prerequisites
- Google Cloud account → https://cloud.google.com
- Google Cloud CLI installed → https://cloud.google.com/sdk/docs/install
- Docker installed (optional for local build)

### Step 1: Create Google Cloud Project

```bash
# Login
gcloud auth login

# Create project (or use existing)
gcloud projects create student-brain-ai-prod
gcloud config set project student-brain-ai-prod

# Enable APIs
gcloud services enable run.googleapis.com
gcloud services enable cloudbuild.googleapis.com
gcloud services enable secretmanager.googleapis.com
gcloud services enable containerregistry.googleapis.com
```

### Step 2: Store API Key Securely

```bash
# Store Anthropic API key in Secret Manager
echo -n "sk-ant-YOUR_KEY_HERE" | \
  gcloud secrets create anthropic-api-key --data-file=-
```

### Step 3: Deploy Backend to Cloud Run

```bash
cd backend

# Build and deploy (auto-builds from Dockerfile)
gcloud run deploy student-brain-backend \
  --source . \
  --platform managed \
  --region us-central1 \
  --allow-unauthenticated \
  --memory 2Gi \
  --cpu 2 \
  --timeout 120 \
  --set-secrets "ANTHROPIC_API_KEY=anthropic-api-key:latest"
```

**Copy the backend URL** (looks like: `https://student-brain-backend-xxxx-uc.a.run.app`)

### Step 4: Deploy Frontend to Cloud Run

```bash
cd frontend

# Add your backend URL to .env
echo "VITE_API_URL=https://student-brain-backend-xxxx-uc.a.run.app" > .env

# Build frontend
npm run build

# Deploy (static files via nginx)
gcloud run deploy student-brain-frontend \
  --source . \
  --platform managed \
  --region us-central1 \
  --allow-unauthenticated \
  --memory 256Mi
```

### Step 5: Visit Your App

```bash
# Get frontend URL
gcloud run services describe student-brain-frontend \
  --region us-central1 \
  --format "value(status.url)"
```

Open that URL in your browser. Done! 🎉

---

## 💡 How the RAG Pipeline Works

```
User uploads PDF
      ↓
Extract text (PyMuPDF)
      ↓
Split into 500-word chunks with 100-word overlap
      ↓
Generate embeddings (all-mpnet-base-v2, 768-dim)
      ↓
Store in FAISS IndexFlatIP (cosine similarity)
      ↓
User asks question
      ↓
Embed query → search FAISS → top-5 chunks
      ↓
Inject chunks into Claude prompt
      ↓
Stream response token-by-token to UI
```

---

## 🔑 Environment Variables

### Backend (.env)
| Variable | Description |
|----------|-------------|
| `ANTHROPIC_API_KEY` | Your Claude API key |
| `PORT` | Server port (default: 8000) |

### Frontend (.env)
| Variable | Description |
|----------|-------------|
| `VITE_API_URL` | Backend URL (e.g., Cloud Run URL) |

---

## 📊 API Reference

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/upload` | POST | Upload & index a PDF/TXT |
| `/api/chat` | POST | Chat with streaming SSE |
| `/api/documents` | GET | List all documents |
| `/api/documents/{id}` | DELETE | Remove a document |
| `/health` | GET | Health check |
| `/docs` | GET | Interactive API docs |

---

## 🔧 Troubleshooting

**Backend won't start?**
- Check Python 3.10+ is installed: `python --version`
- Ensure virtual env is activated
- Check `.env` has valid `ANTHROPIC_API_KEY`

**PDF text extraction failing?**
- Try installing: `pip install PyMuPDF pypdf`
- Scanned/image PDFs won't work (no OCR by default)

**Frontend shows CORS errors?**
- Check `VITE_API_URL` points to your backend
- Backend CORS is set to `allow_origins=["*"]` (open for dev)

**Cloud Run out of memory?**
- Increase to `--memory 4Gi` (sentence-transformers model is ~420MB)

---

## 📈 Scaling & Production Tips

1. **Persistent vector store**: Use Cloud Storage to mount FAISS data (it resets on Cloud Run restarts by default)
2. **Better vector DB**: Replace FAISS with Pinecone or Weaviate for production scale
3. **Auth**: Add Firebase Auth or Supabase for user accounts
4. **File storage**: Move uploads to Cloud Storage GCS
5. **CDN**: Put frontend behind Cloud CDN for global speed

---

## 📄 License

MIT — Build freely, ship proudly.
