import logging
from fastapi import APIRouter, HTTPException
from app.core.rag import load_documents_registry, delete_document

router = APIRouter()
logger = logging.getLogger(__name__)


@router.get("/documents")
async def list_documents():
    """List all indexed documents."""
    registry = load_documents_registry()
    docs = [
        {
            "doc_id": doc_id,
            "filename": info["filename"],
            "chunk_count": info["chunk_count"],
        }
        for doc_id, info in registry.items()
    ]
    return {"documents": docs, "total": len(docs)}


@router.delete("/documents/{doc_id}")
async def remove_document(doc_id: str):
    """Remove a document from the index."""
    success = delete_document(doc_id)
    if not success:
        raise HTTPException(status_code=404, detail="Document not found")
    return {"success": True, "message": "Document removed successfully"}
