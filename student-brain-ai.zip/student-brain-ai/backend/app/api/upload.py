import uuid
import logging
from fastapi import APIRouter, UploadFile, File, HTTPException
from fastapi.responses import JSONResponse
from app.services.extractor import extract_text_from_pdf, extract_text_from_txt
from app.core.rag import add_document

router = APIRouter()
logger = logging.getLogger(__name__)

ALLOWED_TYPES = {
    "application/pdf": "pdf",
    "text/plain": "txt",
    "application/octet-stream": "pdf",  # Some clients send PDFs as octet-stream
}

MAX_FILE_SIZE = 20 * 1024 * 1024  # 20MB


@router.post("/upload")
async def upload_document(file: UploadFile = File(...)):
    """Upload and index a PDF or text document."""
    try:
        # Validate file type
        filename = file.filename or "unknown"
        is_pdf = filename.lower().endswith(".pdf") or file.content_type in ["application/pdf", "application/octet-stream"]
        is_txt = filename.lower().endswith(".txt") or file.content_type == "text/plain"

        if not (is_pdf or is_txt):
            raise HTTPException(
                status_code=400,
                detail="Only PDF and TXT files are supported"
            )

        # Read file
        file_bytes = await file.read()

        if len(file_bytes) > MAX_FILE_SIZE:
            raise HTTPException(
                status_code=400,
                detail=f"File too large. Maximum size is 20MB"
            )

        if len(file_bytes) == 0:
            raise HTTPException(status_code=400, detail="Empty file uploaded")

        # Extract text
        logger.info(f"Processing file: {filename} ({len(file_bytes)} bytes)")

        if is_pdf:
            text = extract_text_from_pdf(file_bytes)
        else:
            text = extract_text_from_txt(file_bytes)

        if len(text.strip()) < 100:
            raise HTTPException(
                status_code=422,
                detail="Could not extract sufficient text from this file. It may be image-based or corrupted."
            )

        # Index document
        doc_id = str(uuid.uuid4())
        chunk_count = add_document(doc_id, filename, text)

        return JSONResponse({
            "success": True,
            "doc_id": doc_id,
            "filename": filename,
            "chunk_count": chunk_count,
            "message": f"Successfully indexed '{filename}' into {chunk_count} searchable sections"
        })

    except HTTPException:
        raise
    except ValueError as e:
        raise HTTPException(status_code=422, detail=str(e))
    except Exception as e:
        logger.error(f"Upload error: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Processing failed: {str(e)}")
