import logging
from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from typing import List, Optional
from app.core.rag import search_similar_chunks
from app.services.ai import generate_response_stream, generate_response

router = APIRouter()
logger = logging.getLogger(__name__)


class ChatMessage(BaseModel):
    role: str  # "user" or "assistant"
    content: str


class ChatRequest(BaseModel):
    message: str
    history: Optional[List[ChatMessage]] = []
    stream: Optional[bool] = True


@router.post("/chat")
async def chat(request: ChatRequest):
    """Process a chat message using RAG and return AI response."""
    if not request.message.strip():
        raise HTTPException(status_code=400, detail="Message cannot be empty")

    try:
        # Retrieve relevant context
        chunks = search_similar_chunks(request.message, top_k=5)
        logger.info(f"Found {len(chunks)} relevant chunks for query: {request.message[:60]}...")

        history = [{"role": m.role, "content": m.content} for m in (request.history or [])]

        if request.stream:
            def stream_response():
                try:
                    for token in generate_response_stream(request.message, chunks, history):
                        yield f"data: {token}\n\n"
                    yield "data: [DONE]\n\n"
                except Exception as e:
                    logger.error(f"Streaming error: {e}")
                    yield f"data: [ERROR] {str(e)}\n\n"

            return StreamingResponse(
                stream_response(),
                media_type="text/event-stream",
                headers={
                    "Cache-Control": "no-cache",
                    "X-Accel-Buffering": "no",
                }
            )
        else:
            response = generate_response(request.message, chunks, history)
            sources = list(set(c["filename"] for c in chunks))
            return {
                "response": response,
                "sources": sources,
                "chunk_count": len(chunks)
            }

    except Exception as e:
        logger.error(f"Chat error: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/chat/sources")
async def get_sources(query: str):
    """Get source chunks for a query (for debugging/transparency)."""
    chunks = search_similar_chunks(query, top_k=3)
    return {
        "query": query,
        "chunks": [{"filename": c["filename"], "text": c["text"][:200], "score": c["score"]} for c in chunks]
    }
