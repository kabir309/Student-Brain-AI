import io
import logging
from typing import Optional

logger = logging.getLogger(__name__)


def extract_text_from_pdf(file_bytes: bytes) -> str:
    """Extract text from PDF bytes using PyMuPDF (fitz) with fallback to pypdf."""
    text = ""

    # Primary: PyMuPDF (fast, accurate)
    try:
        import fitz  # PyMuPDF
        doc = fitz.open(stream=file_bytes, filetype="pdf")
        pages_text = []
        for page_num, page in enumerate(doc):
            page_text = page.get_text("text")
            if page_text.strip():
                pages_text.append(f"[Page {page_num + 1}]\n{page_text.strip()}")
        doc.close()
        text = "\n\n".join(pages_text)
        if text.strip():
            logger.info(f"Extracted {len(text)} chars via PyMuPDF")
            return clean_text(text)
    except ImportError:
        logger.warning("PyMuPDF not available, trying pypdf")
    except Exception as e:
        logger.warning(f"PyMuPDF failed: {e}, trying fallback")

    # Fallback: pypdf
    try:
        from pypdf import PdfReader
        reader = PdfReader(io.BytesIO(file_bytes))
        pages_text = []
        for i, page in enumerate(reader.pages):
            page_text = page.extract_text() or ""
            if page_text.strip():
                pages_text.append(f"[Page {i + 1}]\n{page_text.strip()}")
        text = "\n\n".join(pages_text)
        if text.strip():
            logger.info(f"Extracted {len(text)} chars via pypdf")
            return clean_text(text)
    except Exception as e:
        logger.error(f"pypdf also failed: {e}")

    raise ValueError("Could not extract text from PDF. The file may be scanned or image-based.")


def extract_text_from_txt(file_bytes: bytes) -> str:
    """Extract text from plain text file."""
    for encoding in ["utf-8", "latin-1", "cp1252"]:
        try:
            return clean_text(file_bytes.decode(encoding))
        except UnicodeDecodeError:
            continue
    raise ValueError("Could not decode text file")


def clean_text(text: str) -> str:
    """Clean and normalize extracted text."""
    import re
    # Normalize whitespace
    text = re.sub(r'\n{3,}', '\n\n', text)
    text = re.sub(r'[ \t]+', ' ', text)
    # Remove control characters except newlines/tabs
    text = re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]', '', text)
    return text.strip()
