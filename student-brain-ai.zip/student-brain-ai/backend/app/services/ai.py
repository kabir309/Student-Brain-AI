import os
import anthropic
import logging
from typing import List, Dict, Iterator

logger = logging.getLogger(__name__)

client = anthropic.Anthropic(api_key=os.environ.get("ANTHROPIC_API_KEY"))

SYSTEM_PROMPT = """You are Student Brain AI — an elite, patient, and encouraging study assistant.

Your core teaching philosophy:
1. CLARITY FIRST: Start with the simplest, clearest explanation possible
2. BUILD UP: Layer complexity gradually — concept → context → application
3. USE EXAMPLES: Always ground abstract ideas in concrete, relatable examples
4. STAY ACCURATE: Only use information from the provided study material
5. ENCOURAGE: Be warm and supportive — students learn better without fear

Response structure:
- Lead with a direct, simple answer (1-2 sentences)
- Explain the "why" with an analogy or example
- Add depth or nuance if the topic warrants it
- If the document doesn't cover the topic, say so honestly

Formatting:
- Use **bold** for key terms
- Use bullet points for lists
- Use numbered steps for processes
- Keep paragraphs short and scannable

If the context doesn't contain relevant information to answer the question, be honest:
"I don't see coverage of that specific topic in your uploaded materials. 
Could you check if you've uploaded the right document, or ask me something else?"

Never make up facts. Never hallucinate. Accuracy is paramount."""


def build_context(chunks: List[Dict]) -> str:
    """Build context string from retrieved chunks."""
    if not chunks:
        return "No relevant content found in uploaded documents."

    context_parts = []
    seen_docs = set()

    for chunk in chunks:
        doc_label = f"[From: {chunk['filename']}]"
        if chunk['filename'] not in seen_docs:
            seen_docs.add(chunk['filename'])
        context_parts.append(f"{doc_label}\n{chunk['text']}")

    return "\n\n---\n\n".join(context_parts)


def generate_response(
    query: str,
    chunks: List[Dict],
    chat_history: List[Dict] = None
) -> str:
    """Generate AI response using RAG context (non-streaming)."""
    context = build_context(chunks)

    user_message = f"""Study Material Context:
{context}

---

Student Question: {query}

Please answer based on the study material above. Explain clearly as a great teacher would."""

    messages = []
    if chat_history:
        for msg in chat_history[-6:]:  # Last 6 messages for context
            messages.append({"role": msg["role"], "content": msg["content"]})

    messages.append({"role": "user", "content": user_message})

    response = client.messages.create(
        model="claude-sonnet-4-6",
        max_tokens=1500,
        system=SYSTEM_PROMPT,
        messages=messages,
    )

    return response.content[0].text


def generate_response_stream(
    query: str,
    chunks: List[Dict],
    chat_history: List[Dict] = None
) -> Iterator[str]:
    """Generate streaming AI response using RAG context."""
    context = build_context(chunks)

    user_message = f"""Study Material Context:
{context}

---

Student Question: {query}

Please answer based on the study material above. Explain clearly as a great teacher would."""

    messages = []
    if chat_history:
        for msg in chat_history[-6:]:
            messages.append({"role": msg["role"], "content": msg["content"]})

    messages.append({"role": "user", "content": user_message})

    with client.messages.stream(
        model="claude-sonnet-4-6",
        max_tokens=1500,
        system=SYSTEM_PROMPT,
        messages=messages,
    ) as stream:
        for text in stream.text_stream:
            yield text
