import os
import json
import pickle
import hashlib
import numpy as np
from pathlib import Path
from typing import List, Dict, Tuple, Optional
import logging

logger = logging.getLogger(__name__)

VECTOR_STORE_PATH = Path("data/vector_store")
METADATA_PATH = Path("data/metadata")
VECTOR_STORE_PATH.mkdir(parents=True, exist_ok=True)
METADATA_PATH.mkdir(parents=True, exist_ok=True)

EMBEDDING_DIM = 768  # sentence-transformers dim


def get_embedding_model():
    """Lazy load embedding model."""
    from sentence_transformers import SentenceTransformer
    model = SentenceTransformer("all-mpnet-base-v2")
    return model


_embedding_model = None


def embedding_model():
    global _embedding_model
    if _embedding_model is None:
        logger.info("Loading embedding model...")
        _embedding_model = get_embedding_model()
    return _embedding_model


def embed_texts(texts: List[str]) -> np.ndarray:
    """Generate embeddings for a list of texts."""
    model = embedding_model()
    embeddings = model.encode(texts, normalize_embeddings=True, show_progress_bar=False)
    return embeddings.astype(np.float32)


def chunk_text(text: str, chunk_size: int = 500, overlap: int = 100) -> List[str]:
    """Split text into overlapping chunks for better context preservation."""
    words = text.split()
    chunks = []
    start = 0
    while start < len(words):
        end = min(start + chunk_size, len(words))
        chunk = " ".join(words[start:end])
        if len(chunk.strip()) > 50:  # Skip tiny chunks
            chunks.append(chunk)
        start += chunk_size - overlap
    return chunks


def get_faiss_index():
    """Load or create FAISS index."""
    import faiss
    index_path = VECTOR_STORE_PATH / "index.faiss"
    if index_path.exists():
        index = faiss.read_index(str(index_path))
        logger.info(f"Loaded existing FAISS index with {index.ntotal} vectors")
    else:
        index = faiss.IndexFlatIP(EMBEDDING_DIM)  # Inner product for cosine sim
        logger.info("Created new FAISS index")
    return index


def save_faiss_index(index):
    import faiss
    faiss.write_index(index, str(VECTOR_STORE_PATH / "index.faiss"))


def load_chunk_metadata() -> List[Dict]:
    meta_path = METADATA_PATH / "chunks.pkl"
    if meta_path.exists():
        with open(meta_path, "rb") as f:
            return pickle.load(f)
    return []


def save_chunk_metadata(metadata: List[Dict]):
    with open(METADATA_PATH / "chunks.pkl", "wb") as f:
        pickle.dump(metadata, f)


def load_documents_registry() -> Dict:
    reg_path = METADATA_PATH / "documents.json"
    if reg_path.exists():
        with open(reg_path, "r") as f:
            return json.load(f)
    return {}


def save_documents_registry(registry: Dict):
    with open(METADATA_PATH / "documents.json", "w") as f:
        json.dump(registry, f, indent=2)


def add_document(doc_id: str, filename: str, text: str) -> int:
    """Process and index a document. Returns number of chunks added."""
    import faiss

    # Chunk the text
    chunks = chunk_text(text)
    if not chunks:
        raise ValueError("No content could be extracted from the document")

    # Generate embeddings
    embeddings = embed_texts(chunks)

    # Load existing data
    index = get_faiss_index()
    metadata = load_chunk_metadata()
    registry = load_documents_registry()

    # Store chunks in metadata
    start_id = len(metadata)
    for i, (chunk, emb) in enumerate(zip(chunks, embeddings)):
        metadata.append({
            "id": start_id + i,
            "doc_id": doc_id,
            "filename": filename,
            "chunk_index": i,
            "text": chunk,
        })

    # Add to FAISS
    index.add(embeddings)

    # Update document registry
    registry[doc_id] = {
        "filename": filename,
        "chunk_count": len(chunks),
        "start_id": start_id,
    }

    # Persist
    save_faiss_index(index)
    save_chunk_metadata(metadata)
    save_documents_registry(registry)

    logger.info(f"Indexed {len(chunks)} chunks for document '{filename}'")
    return len(chunks)


def search_similar_chunks(query: str, top_k: int = 5) -> List[Dict]:
    """Retrieve most relevant chunks for a query."""
    import faiss
    metadata = load_chunk_metadata()
    if not metadata:
        return []

    index = get_faiss_index()
    if index.ntotal == 0:
        return []

    query_emb = embed_texts([query])
    scores, indices = index.search(query_emb, min(top_k, index.ntotal))

    results = []
    for score, idx in zip(scores[0], indices[0]):
        if idx >= 0 and score > 0.2:  # Relevance threshold
            chunk = metadata[idx].copy()
            chunk["score"] = float(score)
            results.append(chunk)

    return results


def delete_document(doc_id: str) -> bool:
    """Remove a document and rebuild the index without it."""
    registry = load_documents_registry()
    if doc_id not in registry:
        return False

    metadata = load_chunk_metadata()
    new_metadata = [m for m in metadata if m["doc_id"] != doc_id]

    # Rebuild index
    import faiss
    new_index = faiss.IndexFlatIP(EMBEDDING_DIM)
    if new_metadata:
        texts = [m["text"] for m in new_metadata]
        embeddings = embed_texts(texts)
        new_index.add(embeddings)

    # Re-assign IDs
    for i, m in enumerate(new_metadata):
        m["id"] = i

    del registry[doc_id]

    save_faiss_index(new_index)
    save_chunk_metadata(new_metadata)
    save_documents_registry(registry)

    logger.info(f"Deleted document {doc_id}")
    return True
